"""Test functionality related to the docstore objects."""
