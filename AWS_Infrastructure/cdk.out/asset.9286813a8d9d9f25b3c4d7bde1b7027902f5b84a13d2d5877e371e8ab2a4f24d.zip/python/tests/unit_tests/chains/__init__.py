"""Tests for correct functioning of chains."""
