"""All unit tests for LLM objects."""
