"""Test embedding integrations."""
