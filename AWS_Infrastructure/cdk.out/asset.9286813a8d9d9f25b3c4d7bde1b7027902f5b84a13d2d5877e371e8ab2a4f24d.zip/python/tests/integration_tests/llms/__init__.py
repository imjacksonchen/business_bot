"""All integration tests for LLM objects."""
